package com.example.greetingapp

import android.annotation.SuppressLint
import android.graphics.Color
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.inputmethod.InputMethodManager
import android.content.Context
import android.widget.*

class MainActivity : AppCompatActivity() {
    @SuppressLint("SetTextI18n")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val etName = findViewById<EditText>(R.id.etName)
        val etAge = findViewById<EditText>(R.id.etAge)
        val btnGreet = findViewById<Button>(R.id.btnGreet)
        val btnClear = findViewById<Button>(R.id.btnClear)
        val tvResult = findViewById<TextView>(R.id.tvResult)

        btnGreet.setOnClickListener {
            val name = etName.text.toString().trim()
            val ageText = etAge.text.toString().trim()


            if (name.isEmpty()) {
                etName.error = "Please enter your name"
                Toast.makeText(this, "Name is required", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            if (ageText.isEmpty()) {
                etAge.error = "Please enter your age"
                Toast.makeText(this, "Age is required", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val age = ageText.toIntOrNull()
            if (age == null || age > 100) {
                etAge.error = "Please enter a valid age group (1-100)"
                Toast.makeText(this, "Invalid age input", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }


            val ageGroup: String
            val color: Int

            when {
                age < 13 -> {
                    ageGroup = "You are a child."
                    color = Color.BLACK
                }
                age in 13..19 -> {
                    ageGroup = "You are a teenager"
                    color = Color.BLUE
                }
                age in 20..59 -> {
                    ageGroup = "You are an adult."
                    color = Color.GREEN
                }

                else -> {
                    ageGroup = "You are a senior."
                    color = Color.MAGENTA
                }
            }


            val greeting = "Hello, $name! Welcome to Kotlin."
            val info = "Your name has ${name.length} characters."
            val details = "You are $age years old."
            val result = "$greeting\n$info\n$details\n$ageGroup"


            tvResult.text = result
            tvResult.setTextColor(color)


            val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            imm.hideSoftInputFromWindow(etName.windowToken, 0)
        }

        btnClear.setOnClickListener {
            etName.text.clear()
            etAge.text.clear()
            tvResult.text = ""
            tvResult.setTextColor(Color.BLACK)
            etName.requestFocus()
        }
    }
}